﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Breakdown
{
    class Brick : Sprite
    {
        public bool alive;
        public int rowPos;
        public int columnPos;

        public Brick(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed)
            : base(inTexture, inRectangle, inPosition, inSpeed) // takes these from base class
        {
            speedSprite.X = -1;
            inRectangle = new Rectangle(0,0,40,95);
            alive = true;
        }

        public override void Update(Game1 game)
        {
            if (game.gameOver == false)
            {
                positionSprite = positionSprite + speedSprite;
            }
            base.Update(game);
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            if (alive)
            {
                spriteBatch.Draw(textureSprite, rectangleSprite, Color.DarkCyan);
            }

        }
    }
}
