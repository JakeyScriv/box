﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Breakdown
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        public Texture2D playerTexture;
        public Texture2D ballTexture;
        public Texture2D brickTexture;

        public int updateCounter;
        public int playerScore;
        public int playerLives;

        public static int columns = 1;
        public static int rows = 5;

        Player player;
        Ball ball;
        Brick brick;

        Rectangle playerRectangle;
        Rectangle ballRectangle;
        Rectangle brickRectangle;

        Vector2 playerPosition;
        Vector2 ballPosition;
        Vector2 brickPosition;

        List<Sprite> playField = new List<Sprite>();
        Brick[,] brickArray = new Brick[columns, rows];

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            playerTexture = Content.Load<Texture2D>("Player");
            ballTexture = Content.Load<Texture2D>("Ball");
            brickTexture = Content.Load<Texture2D>("Player");

            playerRectangle = new Rectangle(0, 0, 40, 70);
            playerPosition = new Vector2(10, GraphicsDevice.Viewport.Height / 2);
            player = new Player(playerTexture, playerRectangle, playerPosition, Vector2.Zero);
            playField.Add(player);

            ballRectangle = new Rectangle(0, 0, 30, 30);
            ballPosition = new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2);
            ball = new Ball(ballTexture, ballRectangle, ballPosition, Vector2.Zero);
            playField.Add(ball);
         
            for (int r = 0; r < rows; r++)
            {
                for (int c = 0; c < columns; c++)
                {
                    // starting position of brick wall
                    brickRectangle = new Rectangle(0,0, 40, 95);
                    brickPosition = new Vector2(Window.ClientBounds.Width + 50, 95 * r);
                    brick = new Brick(brickTexture, brickRectangle ,brickPosition, Vector2.Zero);
                    brickArray[c, r] = brick;
                    playField.Add(brick);

                }
            }        
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            /// INDIVIDUAL SPRITE UPDATING
            foreach (Sprite s in playField)
            {
                s.Update(this);
            }

            //collide the ball with the bricks
            brickCollision();
            //collide the ball with the player
            playerBallCollision();

            base.Update(gameTime);
        }

        public void brickCollision()
        {
            //for each brick
            foreach (Brick b in brickArray)
            {
                //if the brick is alive, check for collisions with the ball and resolve them
                if (b.alive)
                {
                    if (ball.rectangleSprite.Intersects(b.rectangleSprite))
                    {
                        if (ball.speedSprite.X > 0)
                        {
                            ball.positionSprite.X = b.rectangleSprite.X - ball.rectangleSprite.Width;
                            ball.speedSprite.X = -ball.speedSprite.X;
                            b.alive = false;
                        }
                        else
                        {
                            ball.positionSprite.X = b.rectangleSprite.X + b.rectangleSprite.Width + ball.rectangleSprite.Width;
                            ball.speedSprite.X = -ball.speedSprite.X;
                            b.alive = false;
                        }

                        Debug.WriteLine("collided");
                    }
                }
            }
        }

        public void playerBallCollision()
        {
            if (ball.rectangleSprite.Intersects(player.rectangleSprite))
            {
                ball.positionSprite.X = player.positionSprite.X + player.rectangleSprite.Width;
                ball.speedSprite.X = -ball.speedSprite.X;
            }
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();



            /// INDIVIDUAL SPRITE PRINTING
            foreach (Sprite s in playField)
            {
                s.Draw(spriteBatch);
            }

            base.Draw(gameTime);
            spriteBatch.End();
        }
    }
}
