﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Breakdown
{
    class Player : Sprite
    {
        public Player(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed)
            : base(inTexture, inRectangle, inPosition, inSpeed) // takes these from base class
        {
            
        }

        public override void Update(Game1 game)
        {
            // gets the keyboard state
            KeyboardState keystate = Keyboard.GetState();

            positionSprite = positionSprite + speedSprite;

            if (keystate.IsKeyDown(Keys.Up))
            {
                speedSprite.Y = -2;
            }
            else if (keystate.IsKeyDown(Keys.Down))
            {
                speedSprite.Y = 2;
            }
        }
    }
}
