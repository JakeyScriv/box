﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Breakdown
{
    class Player : Sprite
    {
        public Player(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed)
            : base(inTexture, inRectangle, inPosition, inSpeed) // takes these from base class
        {
            
        }

        public void playerMovement(KeyboardState keystate)
        {
            positionSprite = positionSprite + speedSprite;

            if (keystate.IsKeyDown(Keys.Up) && keystate.IsKeyDown(Keys.Down))
            {
                speedSprite.Y = 0;
            }
            else if (keystate.IsKeyDown(Keys.Up))
            {
                speedSprite.Y = -4;
            }
            else if (keystate.IsKeyDown(Keys.Down))
            {
                speedSprite.Y = 4;
            }
            else
            {
                speedSprite.Y = 0;
            }
        }

        public void screenBounds(Game1 game)
        {
            if (positionSprite.Y < 0)
            {
                positionSprite.Y = 0;
            }
            if (positionSprite.Y > game.Window.ClientBounds.Height - rectangleSprite.Height)
            {
                positionSprite.Y = game.Window.ClientBounds.Height - rectangleSprite.Height;
            }
        }


        public override void Update(Game1 game)
        {
            // gets the keyboard state
            KeyboardState keystate = Keyboard.GetState();

            if (game.gameOver == false)
            {
                playerMovement(keystate);
            }
            screenBounds(game);
            base.Update(game);
        }
    }
}
