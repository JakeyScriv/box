﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Breakdown
{
    class Player : Sprite
    {
        public Player(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed)
            : base(inTexture, inRectangle, inPosition, inSpeed) // takes these from base class
        {
            
        }

        public override void Update(Game1 game)
        {
            // gets the keyboard state
            KeyboardState keystate = Keyboard.GetState();
            playerMove(keystate);
            clamp(game);
        }

        public void playerMove(KeyboardState keystate)
        {
            position += speed;

            if (keystate.IsKeyDown(Keys.Up))
            {
                speed.Y = -4;
            }
            else if (keystate.IsKeyDown(Keys.Down))
            {
                speed.Y = 4;
            }
            else
            {
                speed.Y = 0;
            }
        }

        public void clamp(Game1 game)
        {
            if (position.Y < 0)
            {
                position.Y = 0;
            }
            if (position.Y > game.Window.ClientBounds.Height - rectangle.Height)
            {
                position.Y = game.Window.ClientBounds.Height - rectangle.Height;
            }
        }
    }
}
