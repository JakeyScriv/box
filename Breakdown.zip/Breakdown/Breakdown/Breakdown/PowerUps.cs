﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Breakdown
{
    class Powerup:Sprite
    {
        public enum Type
        {
            threeBalls,
            biggerPaddle,
            SmallerPaddle,
            fasterBall,
            shooting,
            extraLife,
            bricksFreeze
        }

        Random rnd = new Random();
        int intType = 0;
        Type PowerType;
        public bool alive = false;

        public Powerup(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed, Game1 game) 
            : base(inTexture, inRectangle, inPosition, inSpeed) // takes these from base class
        {
            speedSprite.X = -1;
            alive = true;
            getType(game);
        }

        public void getType(Game1 game)
        {
            intType = rnd.Next(0, 7);

            switch (intType)
            {
                case 0:
                    PowerType = Type.threeBalls;
                    textureSprite = game.threeBallTexture;
                    break;
                case 1:
                    PowerType = Type.biggerPaddle;
                    textureSprite = game.biggerPaddleTexture;
                    break;
                case 2:
                    PowerType = Type.SmallerPaddle;
                    textureSprite = game.smallerPaddleTexture;
                    break;
                case 3:
                    PowerType = Type.fasterBall;
                    textureSprite = game.fasterBallTexture;
                    break;
                case 4:
                    PowerType = Type.shooting;
                    textureSprite = game.shootingTexture;
                    break;
                case 5:
                    PowerType = Type.extraLife;
                    textureSprite = game.extraLifeTexture;
                    break;
                case 6:
                    PowerType = Type.bricksFreeze;
                    textureSprite = game.freezeTexture;
                    break;
            }
        }

        public override void Update(Game1 game)
        {
            if (game.gameOver == false)
            {
                positionSprite = positionSprite + speedSprite;
            }
            base.Update(game);
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            if (alive)
            {
                spriteBatch.Draw(textureSprite, rectangleSprite, Color.White);
            }
        }
    }
}
