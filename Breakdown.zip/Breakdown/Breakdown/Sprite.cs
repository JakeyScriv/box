﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Breakdown
{
    class Sprite
    {
        // Sprite Information
        protected Texture2D textureSprite;
        protected Vector2 position;
        protected Rectangle rectangle;
        protected Vector2 speed;

        public Sprite(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed)
        {
            textureSprite = inTexture;
            rectangle = inRectangle;
            position = inPosition;
            speed = inSpeed;
        }

        public virtual void Update(Game1 game)
        {
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            rectangle.X = (int)Math.Round(position.X + 0.5f);
            rectangle.Y = (int)Math.Round(position.Y + 0.5f);
            spriteBatch.Draw(textureSprite, rectangle, Color.White);
        }
    }
}
