﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Breakdown
{
    class Ball : Sprite
    {
        public Ball(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed)
            : base(inTexture, inRectangle, inPosition, inSpeed) // takes these from base class
        {
            speedSprite.X = -4;
            speedSprite.Y = -4;
        }

        //Check collisions with the edge of the screen, if collided then rebound
        public void edgeCollision(Game1 game)
        {
            if (positionSprite.X > game.Window.ClientBounds.Width - rectangleSprite.Width)
            {
                positionSprite.X = game.Window.ClientBounds.Width - rectangleSprite.Width;
                speedSprite.X = -speedSprite.X;
            }
            if (positionSprite.X < 0)
            {
                positionSprite.X = 0;
                speedSprite.X = -speedSprite.X;
            }
            if (positionSprite.Y > game.Window.ClientBounds.Height - rectangleSprite.Height)
            {
                positionSprite.Y = game.Window.ClientBounds.Height - rectangleSprite.Height;
                speedSprite.Y = -speedSprite.Y;
            }
            if (positionSprite.Y < 0)
            {
                positionSprite.Y = 0;
                speedSprite.Y = -speedSprite.Y;
            }
        }
        public override void Update(Game1 game)
        {
            if (game.gameOver == false)
            {
                positionSprite = positionSprite + speedSprite;
            }

            edgeCollision(game);
            base.Update(game);
        }
    }
}
