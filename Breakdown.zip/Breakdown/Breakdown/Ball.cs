﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Breakdown
{
    class Ball : Sprite
    {
        public Ball(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed)
            : base(inTexture, inRectangle, inPosition, inSpeed) // takes these from base class
        {
            speed.X = 4;
            speed.Y = 4;
        }

        public override void Update(Game1 game)
        {
            ballMove();
            edgeCollision(game);
        }

        //Ball movement
        public void ballMove()
        {
            position += speed;
        }

        //Bounce the ball off the edges of the screen
        public void edgeCollision(Game1 game)
        {
            if (position.X > game.Window.ClientBounds.Width - rectangle.Width)
            {
                position.X = game.Window.ClientBounds.Width - rectangle.Width;
                speed.X = -speed.X;
            }
            if (position.X < 0)
            {
                position.X = 0;
                speed.X = -speed.X;
            }
            if (position.Y > game.Window.ClientBounds.Height - rectangle.Height)
            {
                position.Y = game.Window.ClientBounds.Height - rectangle.Height;
                speed.Y = -speed.Y;
            }
            if (position.Y < 0)
            {
                position.Y = 0;
                speed.Y = -speed.Y;
            }
        }
    }
}