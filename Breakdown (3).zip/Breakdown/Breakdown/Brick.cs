﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Breakdown
{
    class Brick : Sprite
    {
        public Brick(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed)
            : base(inTexture, inRectangle, inPosition, inSpeed) // takes these from base class
        {
            speedSprite.X = -1;
        }

        public override void Update(Game1 game)
        {
            positionSprite = positionSprite + speedSprite;
        }
    }
}
