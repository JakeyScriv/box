﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Breakdown
{
    class Sprite
    {
        // Sprite Information
        protected Texture2D textureSprite;
        protected Vector2 positionSprite;
        protected Rectangle rectangleSprite;
        protected Vector2 speedSprite;

        public Sprite(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed)
        {
            textureSprite = inTexture;
            rectangleSprite = inRectangle;
            positionSprite = inPosition;
            speedSprite = inSpeed;
        }

        public virtual void Update(Game1 game)
        {
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            rectangleSprite.X = (int)Math.Round(positionSprite.X + 0.5f);
            rectangleSprite.Y = (int)Math.Round(positionSprite.Y + 0.5f);
            spriteBatch.Draw(textureSprite, rectangleSprite, Color.White);
        }
    }
}
