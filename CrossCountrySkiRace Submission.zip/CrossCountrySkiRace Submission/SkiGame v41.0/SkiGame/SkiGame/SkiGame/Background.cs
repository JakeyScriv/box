﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace SkiGame
{
    class Background : Sprite
    {
        /// <summary>
        /// the constructor for the background
        /// </summary>
        /// <param name="inTexture">the texture of the background</param>
        /// <param name="inRectangle">the rectange of the background</param>
        /// <param name="inPosition">the position of the background (there are two backgrounds that are tiled to create the moving background)</param>
        /// <param name="inSpeed">the speed of the background</param>
        public Background(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed)
            : base(inTexture, inRectangle, inPosition, inSpeed)
        {
            speed.Y = -2;
        }

        /// <summary>
        /// the overriden update method for the background loops the background from top to bottom when it goes fully off the screen to make the moving background effect
        /// </summary>
        /// <param name="game"></param>
        public override void update(Game1 game)
        {
            //Increase speed every 1000 ticks
            if ((game.ticks % 1000 == 0) && (game.ticks != 0) && (speed.Y > -10))
            {
                speed.Y -= 1;
            }

            //Update position
            position += speed;

            //When the background is fully offscreen set it to the bottom of the screen
            if (position.Y + rectangle.Height <= 0)
            {
                position.Y = game.Window.ClientBounds.Height;
            }
        }
    }
}
