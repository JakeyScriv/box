﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace SkiGame
{
    class Cheese : Sprite
    {
        public bool collided = false;

        /// <summary>
        /// the constructor for the cheese class
        /// </summary>
        /// <param name="inTexture">the texture of the cheese</param>
        /// <param name="inRectangle">the rectangle of the cheese, used for collisions</param>
        /// <param name="inPosition">the position of the cheese, used for movement</param>
        /// <param name="inSpeed">the speed of the cheese</param>
        /// <param name="game">a reference to the game used to base the speed off the length of time the game has been runnning</param>
        public Cheese(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed, Game1 game) : base(inTexture, inRectangle, inPosition, inSpeed)
        {
            speed.X = 0;
            //Sets Y speed based on the game time
            speed.Y = -2 - (int)(game.ticks / 1000);

            //Clamps speed at -10
            if (speed.Y < -10)
            {
                speed.Y = -10;
            }
        }

        /// <summary>
        /// calls the base save method
        /// </summary>
        /// <param name="writer">the streamwriter</param>
        public override void save(StreamWriter writer)
        {
            base.save(writer);
        }

        /// <summary>
        /// calls the base load method
        /// </summary>
        /// <param name="reader">the streamreader</param>
        public override void load(StreamReader reader)
        {
            base.load(reader);
        }

        /// <summary>
        /// the overridden update method for cheese, updates the cheeses position and updates the speed if necessary
        /// </summary>
        /// <param name="game">a reference to the game</param>
        public override void update(Game1 game)
        {
            //update position
            position += speed;

            //Increase speed every 1000 ticks
            if ((game.ticks % 1000 == 0) && (game.ticks != 0) && (speed.Y > -10))
            {
                speed.Y -= 1;
            }
        }

        /// <summary>
        /// resets the cheese if it has gone off the screen and a new cheese is being placed, this reuses the cheese
        /// </summary>
        /// <param name="x">the x position of the cheese</param>
        /// <param name="y">the y position of the cheese</param>
        /// <param name="game">a reference to the game</param>
        public void resetCheese(int x, int y, Game1 game)
        {
            //Set position to given parameters and set alive
            position.Y = y;
            position.X = x;
            alive = true;

            speed.X = 0;
            //Sets Y speed based on the game time
            speed.Y = -2 - (int)(game.ticks / 1000);

            //Clamps speed at -10
            if (speed.Y < -10)
            {
                speed.Y = -10;
            }

            collided = false;
        }
    }
}
