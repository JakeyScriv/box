﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace SkiGame
{                              
    class Flag : Sprite
    {
        //enum stores if the flag is a left flag or right flag
        public enum leftOrRight
        {
            left,
            right
        }

        public leftOrRight flagType;
        public bool scored = false;
        public bool collided = false;

        /// <summary>
        /// the constructor for the flag class
        /// </summary>
        /// <param name="inTexture">the texture of the flag</param>
        /// <param name="inRectangle">the rectangle of the flag used for collisions</param>
        /// <param name="inPosition">the position of the flag used for movement</param>
        /// <param name="inSpeed">the speed of the flag, increases over time</param>
        /// <param name="inLeftOrRight">a structure which stores whether the flag is the left or right flag of its pair</param>
        /// <param name="inScored">a bool storing if the player has scored this flag</param>
        /// <param name="inCollided">a bool storing if the player has collided with this flag</param>
        public Flag(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed, leftOrRight inLeftOrRight, bool inScored, bool inCollided) : base(inTexture, inRectangle, inPosition, inSpeed)
        {
            speed.X = 0;
            speed.Y = -2;
            flagType = inLeftOrRight;
            scored = inScored;
            collided = inCollided;
        }

        /// <summary>
        /// manually saves the flag type as left or right then saves its position, speed, flagtype, collided status and scored status
        /// </summary>
        /// <param name="writer">the streamwriter</param>
        public override void save(StreamWriter writer)
        {
            if (flagType == leftOrRight.left)
            {
                writer.WriteLine("leftFlag");
            }
            else
            {
                writer.WriteLine("rightFlag");
            }
            writer.WriteLine(position.X);
            writer.WriteLine(position.Y);
            writer.WriteLine(speed.X);
            writer.WriteLine(speed.Y);
            writer.WriteLine(flagType);
            writer.WriteLine(collided);
            writer.WriteLine(scored);

        }

        /// <summary>
        /// calls the base load method before loading its flag type, collision status and scored status
        /// </summary>
        /// <param name="reader"></param>
        public override void load(StreamReader reader)
        {
            base.load(reader);
            //read and assign flag type
            if (reader.ReadLine() == "left")
            {
                flagType = leftOrRight.left;
            }
            else
            {
                flagType = leftOrRight.right;
            }
            //read and assign collided status
            if (reader.ReadLine() == "true")
            {
                collided = true;
            }
            else
            {
                collided = false;
            }
            //read and assign scored status
            if (reader.ReadLine() == "true")
            {
                scored = true;
            }
            else
            {
                scored = false;
            }
        }


        /// <summary>
        /// the overriden update method for flag updates its position and speed if necessary. Also resets the cheese to the bottom of the screen with the next x position when it hits the top of the screen
        /// </summary>
        /// <param name="game">a reference to the game</param>
        public override void update(Game1 game)
        {
            //update position
            position += speed;

            //Increase speed every 1000 ticks
            if ((game.ticks % 1000 == 0) && (game.ticks != 0) && (speed.Y > -10))
            {
                speed.Y -= 1;
            }

            //if the flag has gone off the top of the screen reset it in the next position
            if (position.Y < -5)
            {
                position.Y = game.Window.ClientBounds.Height;
                scored = false;
                collided = false;
                if (flagType == leftOrRight.left)
                {
                    position.X = (float)(((game.waveAmplitude / 50) * Math.Sin(game.ticks / 50)) + 50 + (30 * Math.Log(game.ticks)));
                }
                else if (flagType == leftOrRight.right)
                {
                    position.X = (float)(((game.waveAmplitude / 50) * Math.Sin(game.ticks / 50)) + 800 - (30 * Math.Log(game.ticks)));
                }
            }
        }
    }
}
