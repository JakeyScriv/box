﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace SkiGame
{
    class Sprite
    {
        protected Texture2D texture;
        protected Rectangle rectangle;
        protected Vector2 position;
        protected Vector2 speed;
        public bool alive;

        /// <summary>
        /// Returns true if the target has intersected with this object
        /// </summary>
        /// <param name="target">the target sprite that the code checks for collisions with</param>
        /// <returns>a bool to show if the 2 rectangles have collided</returns>
        public bool CollidedWith(Sprite target)
        {
            return rectangle.Intersects(target.rectangle);
        }

        /// <summary>
        /// Checks if the current sprite has passed between the 2 target sprites (used for flags and point scoring)
        /// </summary>
        /// <param name="target1">the first target (left)</param>
        /// <param name="target2">the second target (right)</param>
        /// <returns>returns true if the current sprite has passed between the 2 target sprites</returns>
        public bool HasPassedBetween(Sprite target1, Sprite target2)
        {
            if ((position.Y > target1.position.Y) && (position.X > target1.position.X) && (position.X < target2.position.X))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Constructor for the sprite class
        /// </summary>
        /// <param name="inTexture">the given texture</param>
        /// <param name="inRectangle">the given rectangle</param>
        /// <param name="inPosition">the given position</param>
        /// <param name="inSpeed">the given speed</param>
        public Sprite(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed)
        {
            texture = inTexture;
            rectangle = inRectangle;
            position = inPosition;
            speed = inSpeed;
            alive = true;
        }

        /// <summary>
        /// Virtual update can be overridden by children for their unique update functions, the sprite version does nothing
        /// </summary>
        /// <param name="game">a reference to the game</param>
        public virtual void update(Game1 game)
        {

        }

        /// <summary>
        /// Saves the sprites current position, rectangle and speed into a file "SaveGame.txt", can be overridden
        /// </summary>
        public virtual void save(StreamWriter writer)
        {
            //Write the speed position and type
            writer.WriteLine(this.GetType().Name);
            writer.WriteLine(position.X);
            writer.WriteLine(position.Y);
            writer.WriteLine(speed.X);
            writer.WriteLine(speed.Y);
        }

        /// <summary>
        /// Loads the sprites current position, rectangle and speed into a file "SaveGame.txt", can be overridden
        /// </summary>
        public virtual void load(StreamReader reader)
        {
            //Read the position as a float and convert to vector2
            float positionX = float.Parse(reader.ReadLine());
            float positionY = float.Parse(reader.ReadLine());
            Vector2 loadedPos = new Vector2(positionX, positionY);
            position = loadedPos;
            //Read the speed as a float and converts it to a vector2
            float speedX = float.Parse(reader.ReadLine());
            float speedY = float.Parse(reader.ReadLine());
            Vector2 loadedSpeed = new Vector2(speedX, speedY);
            speed = loadedSpeed;
        }

        /// <summary>
        /// Draws the sprite's texture on the screen in the correct position
        /// </summary>
        /// <param name="spriteBatch">a reference to the spritebatch used for drawing</param>
        public virtual void draw(SpriteBatch spriteBatch)
        {
            rectangle.X = (int)(position.X + 0.5f);
            rectangle.Y = (int)(position.Y + 0.5f);
            spriteBatch.Draw(texture, rectangle, Color.White);
        }


        /// <summary>
        ///Returns whether or not the current sprite is on the screen
        /// </summary>
        /// <param name="game">a reference to this game</param>
        /// <returns></returns>
        public bool isOnScreen(Game1 game)
        {
            if (position.X >= game.Window.ClientBounds.Right || position.X < 0 - texture.Width || position.Y > game.Window.ClientBounds.Height || position.Y < 0 - texture.Width)
            {
                return false;
            }
            return true;
        }
    }
}
