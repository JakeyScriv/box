using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;
using System.Threading.Tasks;
using System.Threading;

namespace SkiGame
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        //Declaring textures
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        public Texture2D playerTexture;
        public Texture2D leftPlayerTexture;
        public Texture2D rightPlayerTexture;
        public Texture2D downPlayerTexture;
        public Texture2D upPlayerTexture;
        Texture2D leftFlagTexture;
        Texture2D rightFlagTexture;
        Texture2D backgroundTexture;
        Texture2D snowballTexture;
        Texture2D cheeseTexture;
        SpriteFont UIFont;

        //Declaring sprite rectangles and vectors
        Vector2 startingPos;
        Rectangle playerRectangle;
        Rectangle backgroundRectangle;
        Rectangle leftFlagRectangle;
        Rectangle rightFlagRectangle;
        Rectangle snowballRectangle;
        Rectangle cheeseRectangle;

        public int ticks;
        public int waveAmplitude;
        int flags;
        int snowballSpawnChance;
        int cheeseSpawnChance = 10000;
        Random rand = new Random();

        List<Sprite> playField = new List<Sprite>();
        List<Flag> flagList = new List<Flag>();
        List<Snowball> snowballList = new List<Snowball>();
        List<Cheese> cheeseList = new List<Cheese>();
        public ParticleSystem particleSystem;

        int lives;
        int score;
        int highscore = 0;
        int timeInGameOver = 0;

        //gameState stores the current state of the game
        public enum gameState
        {
            attract,
            play,
            gameOver
        }

        public gameState currentState = gameState.attract;

        Player player;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }



        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            lives = 3;
            score = 0;
            snowballSpawnChance = 3;
            ticks = 0;
            flags = 0;

            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //load textures
            playerTexture = Content.Load<Texture2D>("StickSkier1");
            leftPlayerTexture = Content.Load<Texture2D>("StickSkier2");
            rightPlayerTexture = Content.Load<Texture2D>("StickSkier3");
            downPlayerTexture = Content.Load<Texture2D>("StickSkier4");
            upPlayerTexture = Content.Load<Texture2D>("StickSkier5");
            leftFlagTexture = Content.Load<Texture2D>("leftBlueFlag");
            rightFlagTexture = Content.Load<Texture2D>("rightRedFlag");
            backgroundTexture = Content.Load<Texture2D>("SnowField");
            snowballTexture = Content.Load<Texture2D>("snowball1");
            cheeseTexture = Content.Load<Texture2D>("cheese");

            //create the background
            backgroundRectangle = new Rectangle(0, 0, Window.ClientBounds.Width, Window.ClientBounds.Height);
            Background background1 = new Background(backgroundTexture, backgroundRectangle, Vector2.Zero, Vector2.Zero);
            playField.Add(background1);
            Vector2 background2Pos = new Vector2(0, Window.ClientBounds.Height);
            Background background2 = new Background(backgroundTexture, backgroundRectangle, background2Pos, Vector2.Zero);
            playField.Add(background2);

            //create the player
            playerRectangle = new Rectangle(0, 0, 40, 40);
            startingPos = new Vector2(Window.ClientBounds.Width / 2, Window.ClientBounds.Height - 100);
            player = new Player(playerTexture, playerRectangle, startingPos, Vector2.Zero);
            playField.Add(player);

            //create the particle system at the players starting position with a max particle number of 20
            particleSystem = new ParticleSystem(snowballTexture, startingPos, 20);

            //load UI font
            UIFont = Content.Load<SpriteFont>("UIFont");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            KeyboardState keystate = Keyboard.GetState();

            //Increment ticks 
            ticks++;
            //Set wave amplitude equal to ticks but cap it at 6000
            waveAmplitude = ticks;
            if (currentState == gameState.play)
            {
                if (waveAmplitude > 6000)
                {
                    waveAmplitude = 6000;
                }
            }
            //if the gamestate is attract cap the waveAmplitude lower
            else if (currentState == gameState.attract)
            {
                if (waveAmplitude > 1500)
                {
                    waveAmplitude = 1500;
                }
            }

            //if lives are less than zero then change state to gameover
            if ((lives == 0) && (currentState == gameState.play))
            {
                currentState = gameState.gameOver;
            }
            //count time in game over state
            if (currentState == gameState.gameOver)
            {
                timeInGameOver++;
            }
            // if in gameoverstate for 10 seconds, reset the game in attract mode
            if (timeInGameOver == 600)
            {
                timeInGameOver = 0;
                currentState = gameState.attract;
                playField.Clear();
                cheeseList.Clear();
                snowballList.Clear();
                flagList.Clear();

                LoadContent();
            }

            //Increase the spawn chance of snowballs
            if (snowballSpawnChance < 4000)
            {
                snowballSpawnChance += 1;
            }

            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();


            //Clears the screen and starts a new game
            if (keystate.IsKeyDown(Keys.N))
            {
                currentState = gameState.play;
                playField.Clear();
                cheeseList.Clear();
                snowballList.Clear();
                flagList.Clear();

                LoadContent();
            }

            //if the player presses Q, quit the game
            if (keystate.IsKeyDown(Keys.Q))
            {
                this.Exit();
            }

            //if r is pressed reload the game from the save file
            if (keystate.IsKeyDown(Keys.R) && (currentState == gameState.play))
            {
                loadGame();
            }
            //if s is pressed save the game
            else if (keystate.IsKeyDown(Keys.S) && (currentState == gameState.play))
            {
                saveGame();
            }

            //Updates all sprites
            updateSprites();

            //update the particle system
            particleSystem.update(this);

            //If play mode and player is dead, set to gameOver
            if ((lives <= 0) && (currentState == gameState.play))
            {
                currentState = gameState.gameOver;
            }

            //if the game is not over
            if (currentState != gameState.gameOver)
            {
                //creates flags if necessary
                createFlags();

                //chance to create snowball
                createSnowballs();

                //scores points for passing flags
                scoring();

                //checks for collisions between the player and flag
                flagCollision();

                //chance to create cheese
                createCheese();

                //checks for collisions between the snowball and the player
                snowballCollision();

                //checks for collisions between the player and cheese
                cheeseCollision();
            }
            base.Update(gameTime);
        }

        /// <summary>
        /// checks for collisions between the player and cheese
        /// </summary>
        public void cheeseCollision()
        {
            //Checks if the player has collided with a cheese and if it has increase the players lives by 1 and set the cheese to collided
            for (int i = 0; i < cheeseList.Count; i++)
            {
                if ((player.CollidedWith(cheeseList[i])) && (cheeseList[i].collided == false))
                {
                    lives += 1;
                    cheeseList[i].collided = true;
                    cheeseList[i].alive = false;
                }
            }
        }

        /// <summary>
        /// checks for collisions between snowballs and the player
        /// </summary>
        public void snowballCollision()
        {
            for (int i = 0; i < snowballList.Count; i++)
            {
                //Checks if the player has collided with a snowball and if it has reduce the players lives by 1 and set the snowball to collided
                if ((player.CollidedWith(snowballList[i])) && (snowballList[i].collided == false))
                {
                    lives -= 1;
                    snowballList[i].collided = true;
                }
            }
        }

        /// <summary>
        /// chance to create cheese between the two flags
        /// </summary>
        public void createCheese()
        {
            //Chance to create cheese between flags
            if (ticks > 240)
            {
                if ((rand.Next(1, 100001) < cheeseSpawnChance) && (ticks % 20 == 0))
                {
                    bool notAlive = false;
                    int idleCheese = -1;

                    //create cheese based on the same sin wave that the flags are based on to ensure it is placed between the flag
                    //randomise position between the flags
                    int cheeseX = rand.Next((int)((waveAmplitude / 50) * Math.Sin(ticks / 50) + (30 * Math.Log(ticks))), (int)((waveAmplitude / 50) * Math.Sin(ticks / 50) + 750 - (30 * Math.Log(ticks))));
                    Vector2 cheesePos = new Vector2(cheeseX, Window.ClientBounds.Height);

                    //find an unused cheese
                    for (int i = 0; i < cheeseList.Count; i++)
                    {
                        if (cheeseList[i].alive == false)
                        {
                            notAlive = true;
                            idleCheese = i;
                        }
                    }

                    //if there is an unused cheese reuse it
                    if (notAlive == true)
                    {
                        cheeseList[idleCheese].resetCheese(cheeseX, Window.ClientBounds.Height, this);
                    }
                    //otherwise create a new one
                    else
                    {
                        cheeseRectangle = new Rectangle(0, 0, 40, 40);
                        Cheese cheese = new Cheese(cheeseTexture, cheeseRectangle, cheesePos, Vector2.Zero, this);
                        playField.Add(cheese);
                        cheeseList.Add(cheese);
                    }

                }
            }
        }

        /// <summary>
        /// Checks collision between the player and flag
        /// </summary>
        public void flagCollision()
        {
            //Checks if the player has collided with a flag and if it has reduce the players lives by 1 and set the flag to collided
            for (int i = 0; i < flagList.Count; i++)
            {
                if ((player.CollidedWith(flagList[i])) && (flagList[i].collided == false))
                {
                    lives -= 1;
                    flagList[i].collided = true;
                }
            }
        }

        /// <summary>
        /// scores points for passing flags
        /// </summary>
        public void scoring()
        {
            //Check for the player passing through each flag pair and score a point if it passes through a new flag pair
            for (int i = 0; i < flagList.Count; i += 2)
            {
                if (player.HasPassedBetween(flagList[i], flagList[i + 1]) && (flagList[i].scored == false))
                {
                    flagList[i].scored = true;
                    score += 1;
                    //if the current score is greater than highscore then update the highscore
                    if ((score > highscore) && (currentState == gameState.play))
                    {
                        highscore = score;
                    }
                }
            }
        }

        /// <summary>
        /// has an increasing chance to create a snowball (reuses snowballs) after the game has run for 240 ticks
        /// </summary>
        public void createSnowballs()
        {
            //after 240 ticks snowballs have a chance to spawn that increases with game time
            if (ticks > 240)
            {
                if (rand.Next(1, 100001) < snowballSpawnChance)
                {

                    bool notAlive = false;
                    int idleSnowball = -1;

                    //find unused snowballs
                    for (int i = 0; i < snowballList.Count; i++)
                    {
                        if (snowballList[i].alive == false)
                        {
                            notAlive = true;
                            idleSnowball = i;
                        }
                    }

                    //if there is an unused snowball, reuse it, otherwise create a new one
                    if (notAlive == true)
                    {
                        snowballList[idleSnowball].resetSnowball(this);
                    }
                    else
                    {
                        snowballRectangle = new Rectangle(0, 0, 40, 40);
                        Snowball snowball = new Snowball(snowballTexture, snowballRectangle, Vector2.Zero, Vector2.Zero, this, false);
                        playField.Add(snowball);
                        snowballList.Add(snowball);
                    }
                }
            }
        }

        /// <summary>
        /// creates flags if there are not enough
        /// </summary>
        public void createFlags()
        {
            //if there are less than 12 sets of flags create a new set
            if (ticks % 20 == 0 && flags < 12 && ticks != 0)
            {
                flags += 1;
                Vector2 flagPos = new Vector2((float)(((waveAmplitude / 50) * Math.Sin(ticks / 50)) + 50 + (30 * Math.Log(ticks))), Window.ClientBounds.Height);
                leftFlagRectangle = new Rectangle(0, 0, 20, 20);
                Flag leftFlag = new Flag(leftFlagTexture, leftFlagRectangle, flagPos, Vector2.Zero, Flag.leftOrRight.left, false, false);
                playField.Add(leftFlag);
                flagList.Add(leftFlag);

                flagPos = new Vector2((float)(((waveAmplitude / 50) * Math.Sin(ticks / 50)) + 800 - (30 * Math.Log(ticks))), Window.ClientBounds.Height);
                rightFlagRectangle = new Rectangle(200, 0, 20, 20);
                Flag rightFlag = new Flag(rightFlagTexture, rightFlagRectangle, flagPos, Vector2.Zero, Flag.leftOrRight.right, false, false);
                playField.Add(rightFlag);
                flagList.Add(rightFlag);
            }
        }

        /// <summary>
        /// Loops through the playfield and updates all sprites it contains
        /// </summary>
        public void updateSprites()
        {
            //Updates all sprites on the screen
            foreach (Sprite s in playField)
            {
                if (s.isOnScreen(this) == false)
                {
                    s.alive = false;
                }
                //Only update if the state is not gameover
                if (currentState != gameState.gameOver)
                {
                    //update the sprite if its alive
                    if (s.alive == true)
                    {
                        //check if the sprite is theplayer, if it is check the gamemode before proceeding
                        if (s == player)
                        {
                            //if the game is in play mode update the player based on controls, otherwise centre the player
                            if (currentState == gameState.play)
                            {
                                s.update(this);
                            }
                            else
                            {
                                player.attractMove(this);
                            }
                        }
                        else
                        {
                            //if the sprite is not a player then update it normally
                            s.update(this);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// saves all important information and then loops every sprite to save itself
        /// </summary>
        public void saveGame()
        {
            //write important game details to save file
            StreamWriter writer = new StreamWriter("SaveGame.txt");
            writer.WriteLine(ticks);
            writer.WriteLine(waveAmplitude);
            writer.WriteLine(snowballSpawnChance);
            writer.WriteLine(score);
            writer.WriteLine(lives);

            //call each sprite to save itself
            foreach (Sprite s in playField)
            {
                s.save(writer);
            }
            writer.Close();
        }

        /// <summary>
        /// loads all important information then loads every item from file
        /// </summary>
        public void loadGame()
        {
            //Clear lists ready to reload a fresh game
            currentState = gameState.play;
            playField.Clear();
            cheeseList.Clear();
            snowballList.Clear();
            flagList.Clear();
            flags = 0;

            StreamReader reader = new StreamReader("SaveGame.txt");
            //Read important game details
            ticks = int.Parse(reader.ReadLine());
            waveAmplitude = int.Parse(reader.ReadLine());
            snowballSpawnChance = int.Parse(reader.ReadLine());
            score = int.Parse(reader.ReadLine());
            lives = int.Parse(reader.ReadLine());

            //read to the end of the file
            while (!reader.EndOfStream)
            {
                //read the type of item from file
                string itemType = reader.ReadLine();

                //Create a new instance of the type read and add them to the relevant lists
                switch (itemType)
                {
                    case "Background":
                        Background loadedItem = new Background(backgroundTexture, backgroundRectangle, Vector2.Zero, Vector2.Zero);
                        loadedItem.load(reader);
                        playField.Add(loadedItem);
                        break;
                    case "Player":
                        playerRectangle = new Rectangle((int)(startingPos.X + 0.5f), (int)(startingPos.Y + 0.5f), 40, 40);
                        player = new Player(playerTexture, playerRectangle, startingPos, Vector2.Zero);
                        player.load(reader);
                        playField.Add(player);
                        break;
                    case "Snowball":
                        Snowball loadedSnowball = new Snowball(snowballTexture, snowballRectangle, Vector2.Zero, Vector2.Zero, this, false);
                        loadedSnowball.load(reader);
                        playField.Add(loadedSnowball);
                        snowballList.Add(loadedSnowball);
                        break;
                    case "Cheese":
                        Cheese loadedCheese = new Cheese(cheeseTexture, cheeseRectangle, Vector2.Zero, Vector2.Zero, this);
                        loadedCheese.load(reader);
                        playField.Add(loadedCheese);
                        cheeseList.Add(loadedCheese);
                        break;
                    case "leftFlag":
                        Flag loadedLeftFlag = new Flag(leftFlagTexture, leftFlagRectangle, Vector2.Zero, Vector2.Zero, Flag.leftOrRight.left, false, true);
                        loadedLeftFlag.load(reader);
                        playField.Add(loadedLeftFlag);
                        flagList.Add(loadedLeftFlag);
                        flags += 1;
                        break;
                    case "rightFlag":
                        Flag loadedRightFlag = new Flag(rightFlagTexture, rightFlagRectangle, Vector2.Zero, Vector2.Zero, Flag.leftOrRight.right, false, true);
                        loadedRightFlag.load(reader);
                        playField.Add(loadedRightFlag);
                        flagList.Add(loadedRightFlag);
                        break;
                    default:
                        throw new Exception("Invalid type in saved file");
                }
            }
            reader.Close();
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.White);
            spriteBatch.Begin();

            //draw all sprites on the screen
            foreach (Sprite s in playField)
            {
                if (s.alive == true)
                {
                    s.draw(spriteBatch);
                }
            }

            //draw the UI depending on gamestate
            if (currentState == gameState.attract)
            {
                spriteBatch.DrawString(UIFont, "Attract Mode: ", new Vector2(300, 300), Color.Black);
                spriteBatch.DrawString(UIFont, "Press N to start a new game", new Vector2(150, 350), Color.Black);
                spriteBatch.DrawString(UIFont, "Highscore: " + highscore, new Vector2(300, 400), Color.Black);
            }
            if (currentState == gameState.play)
            {

                spriteBatch.DrawString(UIFont, "Score: " + score, new Vector2(550, 350), Color.Black);
                spriteBatch.DrawString(UIFont, "Lives: " + lives, new Vector2(550, 400), Color.Black);
            }
            if (currentState == gameState.gameOver)
            {
                spriteBatch.DrawString(UIFont, "Game Over!", new Vector2(300, 200), Color.Black);
                spriteBatch.DrawString(UIFont, "Score: " + score, new Vector2(340, 250), Color.Black);
                spriteBatch.DrawString(UIFont, "Highscore: " + highscore, new Vector2(300, 300), Color.Black);
                spriteBatch.DrawString(UIFont, "Press N to start a new game", new Vector2(150, 350), Color.Black);
            }

            //draw the particles
            particleSystem.draw(spriteBatch);

            //debugging
            //spriteBatch.DrawString(UIFont, "Ticks: " + ticks, new Vector2(10, 10), Color.Black);
            //spriteBatch.DrawString(UIFont, "waveAmplitude: " + waveAmplitude, new Vector2(10, 60), Color.Black);

            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
