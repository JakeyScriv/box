﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace SkiGame
{
    class Player : Sprite
    {
        int movespeed = 2;
        public bool movingRight = true;
        public bool movingLeft = true;
        public bool movingUp = true;
        public bool movingDown = true;

        /// <summary>
        /// the player constructor, inherits from sprite
        /// </summary>
        /// <param name="inTexture">the texture of the palyer</param>
        /// <param name="inRectangle">the rectangle of the player used for collisions</param>
        /// <param name="inPosition">the position of the player used for movement</param>
        /// <param name="inSpeed">the speed of the player</param>
        public Player(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed) : base(inTexture, inRectangle, inPosition, inSpeed)
        {

        }

        /// <summary>
        /// calls the base save
        /// </summary>
        /// <param name="writer">the streamwriter</param>
        public override void save(StreamWriter writer)
        {
            base.save(writer);
        }

        /// <summary>
        /// moves the player around in attract mode
        /// </summary>
        /// <param name="game">a reference to the game</param>
        public void attractMove(Game1 game)
        {
            //update player position
            position += speed;

            //move the player back and forth left and right
            if (movingLeft == true)
            {
                speed.X = 2;
                movingLeft = false;
            }
            if (movingRight == true && position.X + rectangle.Width > ((game.waveAmplitude / 50) * Math.Sin(game.ticks / 50)) + 800 - (30 * Math.Log(game.ticks)))
            {
                speed.X = -2;
                movingRight = false;
            }
            if (movingRight == false && position.X - rectangle.Width < ((game.waveAmplitude / 50) * Math.Sin(game.ticks / 50)) + 50 + (30 * Math.Log(game.ticks)))
            {
                speed.X = 2;
                movingLeft = false;
                movingRight = true;
            }

            //move the player up and down
            if (movingDown == true)
            {
                speed.Y = 2;
                movingDown = false;
            }
            if (movingUp == true && position.Y > 300)
            {
                speed.Y = -2;
                movingUp = false;
            }
            if (movingUp == false && position.Y < 100)
            {
                speed.Y = 2;
                movingDown = false;
                movingUp = true;
            }

            game.particleSystem.originPos = position;
            game.particleSystem.originPos.X += 20;
        }

        /// <summary>
        /// calls the base load
        /// </summary>
        /// <param name="reader">the streamreader</param>
        public override void load(StreamReader reader)
        {
            base.load(reader);
        }

        /// <summary>
        /// the player's overrride of the update method, controls movement, textures and clamps the player on screen
        /// </summary>
        /// <param name="game">a reference to the game</param>
        public override void update(Game1 game)
        {
            KeyboardState keystate = Keyboard.GetState();

            speed.X = 0;
            speed.Y = 0;

            //Controls
            if (keystate.IsKeyDown(Keys.Up))
            {
                speed.Y = -movespeed;
            }
            if (keystate.IsKeyDown(Keys.Down))
            {
                speed.Y = movespeed;
            }
            if (keystate.IsKeyDown(Keys.Left))
            {
                speed.X = -movespeed;
            }
            if (keystate.IsKeyDown(Keys.Right))
            {
                speed.X = movespeed;
            }

            //Set texture (can't be in the control block without preventing diagonal movement or not resetting the texture when the key is let go)

            if (keystate.IsKeyDown(Keys.Down))
            {
                texture = game.downPlayerTexture;
            }
            else if (keystate.IsKeyDown(Keys.Left))
            {
                texture = game.leftPlayerTexture;
            }
            else if (keystate.IsKeyDown(Keys.Right))
            {
                texture = game.rightPlayerTexture;
            }
            else if (keystate.IsKeyDown(Keys.Up))
            {
                texture = game.upPlayerTexture;
            }
            else
            {
                texture = game.playerTexture;
            }

            //updates the position of the player
            position += speed;

            //Clamps the skiier on the screen
            if (position.X < 0)
            {
                position.X = 0;
            }
            if (position.X > game.Window.ClientBounds.Width - rectangle.Width)
            {
                position.X = game.Window.ClientBounds.Width - rectangle.Width;
            }
            if (position.Y < 0)
            {
                position.Y = 0;
            }
            if (position.Y > game.Window.ClientBounds.Height - rectangle.Height)
            {
                position.Y = game.Window.ClientBounds.Height - rectangle.Height;
            }

            game.particleSystem.originPos = position;
            game.particleSystem.originPos.X += 20;
        }
    }
}
