﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;

namespace SkiGame
{
    class Snowball : Sprite
    {
        int spawnPosition;
        Random rand = new Random();
        public bool collided = false;

        /// <summary>
        /// Constructor for the snowball
        /// </summary>
        /// <param name="inTexture">the snowball texture</param>
        /// <param name="inRectangle">the rectangle of the snowball used for collisions</param>
        /// <param name="inPosition">the position of the snowball used for movement</param>
        /// <param name="inSpeed">the speed of the snowball</param>
        /// <param name="game">a reference to the game, used to refer to the height of the game when spawning a new snowball</param>
        /// <param name="Collided">a bool which keeps track of if the player has collided with this snowball</param>
        public Snowball(Texture2D inTexture, Rectangle inRectangle, Vector2 inPosition, Vector2 inSpeed, Game1 game, bool Collided) : base(inTexture, inRectangle, inPosition, inSpeed)
        {
            speed.X = 4;
            speed.Y = 0;
            spawnPosition = rand.Next(0, game.Window.ClientBounds.Height);
            position = new Vector2(0, spawnPosition);
        }

        /// <summary>
        /// calls the base save method to save and also saves its collision status
        /// </summary>
        /// <param name="writer">the streamwriter</param>
        public override void save(StreamWriter writer)
        {
            base.save(writer);
            writer.WriteLine(collided);
        }

        /// <summary>
        /// calls the base load method and also reads its collision status
        /// </summary>
        /// <param name="reader">the streamreader</param>
        public override void load(StreamReader reader)
        {
            base.load(reader);
            if (reader.ReadLine() == "true")
            {
                collided = true;
            }
            else
            {
                collided = false;
            }
        }

        /// <summary>
        /// the snowballs update override updates the position of the snowball
        /// </summary>
        /// <param name="game">a reference to the game</param>
        public override void update(Game1 game)
        {
            //Update the snowball's position
            position += speed;
        }

        /// <summary>
        /// Resets the snowball to the left side of the screen with a new random Y
        /// </summary>
        /// <param name="game">the game instance, used for window height</param>
        public void resetSnowball(Game1 game)
        {
            position.Y = rand.Next(0, game.Window.ClientBounds.Height);
            position.X = 0;
            alive = true;
        }
    }
}
