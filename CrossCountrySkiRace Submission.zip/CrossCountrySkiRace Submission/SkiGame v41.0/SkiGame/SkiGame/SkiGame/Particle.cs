﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SkiGame
{
    class Particle
    {
        Texture2D texture;
        Rectangle rectangle;
        public int lifeTime;
        public bool alive;
        Vector2 speed;
        Vector2 position;
        Random rnd = new Random();

        /// <summary>
        /// constructor for the particle class
        /// </summary>
        /// <param name="inTexture">tyhe texture of the particle</param>
        /// <param name="inLifeTime">the life time of the particle, this reduces over time and the particle dies when this hits 0</param>
        /// <param name="inPosition">the position of the particle(starts at the origin point)</param>
        public Particle(Texture2D inTexture, int inLifeTime, Vector2 inPosition)
        {
            texture = inTexture;
            lifeTime = inLifeTime;
            alive = true;
            speed.X = rnd.Next(-10, 11);
            speed.X = (float)speed.X / 10;
            speed.Y = -2f;
            position = inPosition;
            rectangle = new Rectangle((int)position.X, (int)position.Y, 10, 10);
        }

        /// <summary>
        /// updates the lifetime, position and speed of the particle
        /// </summary>
        public void update()
        {
            lifeTime -= 1;
            position += speed;
            speed.Y += 0.05f;
        }

        /// <summary>
        /// draws the particle if it is alive
        /// </summary>
        /// <param name="spriteBatch">the spritebatch used for drawing</param>
        public void draw(SpriteBatch spriteBatch)
        {
            if (alive)
            {
                rectangle.X = (int)(position.X + 0.5f);
                rectangle.Y = (int)(position.Y + 0.5f);
                spriteBatch.Draw(texture, rectangle, new Color(255, 255, 255, lifeTime * 20));
            }
        }
    }
}
