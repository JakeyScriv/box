﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SkiGame
{
    public class ParticleSystem
    {
        Texture2D particleTexture;
        public Vector2 originPos;
        List<Particle> particles = new List<Particle>();
        int numToSpawn;
        int particleNumber;

        /// <summary>
        /// constructor for the particle system class
        /// </summary>
        /// <param name="inParticleTexture">the texture of the particles</param>
        /// <param name="inOrigin">the origin point of the particles</param>
        /// <param name="inNumToSpawn">the number of particles to have at once</param>
        public ParticleSystem(Texture2D inParticleTexture, Vector2 inOrigin, int inNumToSpawn)
        {
            originPos = inOrigin;
            numToSpawn = inNumToSpawn;
            particleTexture = inParticleTexture;
        }

        /// <summary>
        /// update method, creates a particle every 10 ticks if there are less than the max, finds particles that are old and removes them
        /// </summary>
        /// <param name="game">a refence to the game used to space particle spawning over time</param>
        public void update(Game1 game)
        {

            //spawns particle every 10 ticks if less than max
            if ((particles.Count() < numToSpawn) && (game.ticks % 10 == 0))
            {
                spawnParticle();
            }

            //counts paricles
            particleNumber = particles.Count();

            //finds particles that have expired and set them to not alive
            foreach (Particle p in particles)
            {
                if (p.lifeTime < 0)
                {
                    p.alive = false;
                }
                else
                {
                    p.update();
                }
            }

            //remove not alive particles from list
            for (int i = 0; i < particleNumber - 1; i++)
            {
                if (particles[i].alive == false)
                {
                    particles.Remove(particles[i]);
                }
            }

            //count particles again
            particleNumber = particles.Count();
        }

        /// <summary>
        /// calls draw for each particle
        /// </summary>
        /// <param name="spriteBatch">spritebatch used to draw</param>
        public void draw(SpriteBatch spriteBatch)
        {
            //call each particle to draw itself
            foreach (Particle p in particles)
            {
                p.draw(spriteBatch);
            }
        }

        /// <summary>
        /// spawns a particle and adds it to the list
        /// </summary>
        public void spawnParticle()
        {
            Particle particle = new Particle(particleTexture, 60, originPos);
            particles.Add(particle);
        }
    }
}
